package com.mobsquad.client;



import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import com.mobsquad.constant.Constant;

public class SigninServiceClient {
	static String result1 = " ";

	public static boolean signinclient(String email, String password) {

		try {
			String url = Constant.url+"signin/"
					+ email + "/" + password;

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);

			HttpResponse response = client.execute(request);

			System.out.println("Response Code : "
					+ response.getStatusLine().getStatusCode());
			if (response.getStatusLine().getStatusCode() != 200)
				return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;

	}
	
	/*public static void main(String[] args) {
		SigninServiceClient.signinclient("abc", "123");
	}*/
}
