package com.mobsquad.client;



import org.apache.http.HttpResponse;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import com.mobsquad.constant.Constant;

public class SignupServiceClient {
	static String result2 ="";
	public static boolean signupclient(String email, String password){
		
		try {
		String url = Constant.url+"signup/"+ email + "/" + password;
		
		HttpClient client = new DefaultHttpClient();
		HttpPost request = new HttpPost(url);
	 
		HttpResponse response = client.execute(request);
	 
		System.out.println("Response Code : " 
	                + response.getStatusLine().getStatusCode());
	 
		
		System.out.println("Response Code : "
				+ response.getStatusLine().getStatusCode());
		if (response.getStatusLine().getStatusCode() != 200)
			return false;
	} catch (Exception e) {
		e.printStackTrace();
		return false;
	}

	return true;
			 
		
	}
}
