package com.mobsquad.review;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.mobsquad.client.FeedServiceClient;
import com.mobsquad.constant.Constant;
import com.mobsquad.entity.Feed;

import android.app.Activity;
import android.app.ActionBar;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MyPostsActivity extends Activity {

	private List<Post> myPosts = new ArrayList<Post>();
	SessionManagement session;
	String email;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_my_posts);
		ActionBar bar = getActionBar();
		bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00ccff")));
		
		session = new SessionManagement(getApplicationContext());
		
		HashMap<String, String> userEmail = session.getUserDetails();
		Log.i("session", "Email1");
		email = userEmail.get(SessionManagement.KEY_EMAIL);
		Log.i("session", "Email: " + email);
		
		populatePostList();
		populateListView();
	}

	
	private void populatePostList() {
		
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
		.permitAll().build();
    	StrictMode.setThreadPolicy(policy);

		ArrayList<Feed> feeds = FeedServiceClient.userFeed(email);
		Log.i("session", "Email2");
    	Log.i("dashboard", "Size:" + feeds.size());
    	for(Feed feed: feeds)
    	{
    		Log.i("dashboard", "FileName: " + feed.getImagePath());
    		String[] file = feed.getImagePath().split("/");
    		String fileName = file[file.length-1];
    		Log.i("dashboard", "FileName: " + fileName);
    		Log.i("dashboard", "ReviewId: " + feed.getReviewId());
    		Bitmap image = FeedServiceClient.downloadReviewImage(feed.getReviewId(), fileName);
    		myPosts.add(new Post(feed.getEmail(), Constant.tags + feed.getTags(), Constant.description +feed.getDesp(), image));
    	}

	}

	private void populateListView() {

		ArrayAdapter<Post> adapter = new MyListAdapter();
		ListView list = (ListView) findViewById(R.id.postsListView);
		list.setAdapter(adapter);

	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		getMenuInflater().inflate(R.menu.my_posts, menu);
		return true;
	}


	 @Override
	    public boolean    onOptionsItemSelected       (MenuItem item) {
	    	
		 switch(item.getItemId())
	        {
	    	case R.id.action_logout:
	    		Intent intentlogout = new Intent(this, LoginActivity.class);
	            startActivity(intentlogout);
	            session.logoutUser();
	            finish();
	            break;
	        default:
	        	break;
	        }
	    	return true;
	    	
	    }

	private class MyListAdapter extends ArrayAdapter<Post> {

		public MyListAdapter() {
			super(MyPostsActivity.this, R.layout.postlayout, myPosts);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// Making sure we have a view to work with
			View itemView = convertView;

			if (itemView == null) {

				itemView = getLayoutInflater().inflate(R.layout.postlayout,
						parent, false);

			}

			Post currentPost = myPosts.get(position);

			ImageView imageView = (ImageView) itemView
					.findViewById(R.id.postImage);
			TextView description = (TextView) itemView
					.findViewById(R.id.postDescription);
			TextView tags = (TextView) itemView
					.findViewById(R.id.postTags);

			imageView.setImageBitmap(currentPost.getImage());
			description.setText(currentPost.getDescription());
			tags.setText(currentPost.getTag());

			return itemView;
		}

	}

}
