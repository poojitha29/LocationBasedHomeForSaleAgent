package com.mobsquad.review;


import java.util.HashMap;

import com.mobsquad.client.NewReviewServiceClient;

import android.app.ActionBar;
import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

public class NewReviewActivity extends Activity {

	private static int RESULT_LOAD_IMAGE = 1;
	String picturePath = "";
	SessionManagement session;
	String email;
	
	AlertDialogManager alert = new AlertDialogManager();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new_review);
	
		picturePath = "";
		ActionBar bar = getActionBar();
		bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00ccff")));
		
		session = new SessionManagement(getApplicationContext());
		
		HashMap<String, String> userEmail = session.getUserDetails();
		Log.i("session", "Email1");
		email = userEmail.get(SessionManagement.KEY_EMAIL);
		Log.i("session", "Email: " + email);

		
		
		if (savedInstanceState == null) {
			getFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}

	}

	public void uploadPicClick(View v) {
		Intent i = new Intent(Intent.ACTION_PICK,
				android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		startActivityForResult(i, RESULT_LOAD_IMAGE);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_new_review,
					container, false);
			return rootView;
		}
	}

	
	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	    	
	    	MenuInflater inflater = getMenuInflater();
	    	inflater.inflate(R.menu.new_review, menu);
	    	    
	    	return super.onCreateOptionsMenu(menu);
	    }
	    
	 
	    @Override
	    public boolean onPrepareOptionsMenu(Menu menu) {
	        return super.onPrepareOptionsMenu(menu);
	    }
	 
	   
	public boolean onOptionsItemSelected(MenuItem item) {
	    	
	    	switch(item.getItemId())
	        {
	    	      
	    	case R.id.action_dashboard:
	    		Intent intentrefresh = new Intent(this, DashboardActivity.class);
	            startActivity(intentrefresh);
	            finish();
	            break;
	    	case R.id.action_logout:
	    		Intent intentlogout = new Intent(this, LoginActivity.class);
	            startActivity(intentlogout);
	            session.logoutUser();
	            finish();
	            break;
	    	default:
	    		break;
	        }
	    	return true;
	        }
	    	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK
				&& null != data) {
			Uri selectedImage = data.getData();
			String[] filePathColumn = { MediaStore.Images.Media.DATA };

			Cursor cursor = getContentResolver().query(selectedImage,
					filePathColumn, null, null, null);
			cursor.moveToFirst();

			int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
			picturePath = cursor.getString(columnIndex);
			Log.i("Review", "path: " +picturePath );
			cursor.close();

			ImageView imageView = (ImageView) findViewById(R.id.newReviewImageView);
			imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));

		}

	}

	public void newReviewClick(View v) {
		
		ImageView imageView = (ImageView) findViewById(R.id.newReviewImageView);
		EditText tag = (EditText) findViewById(R.id.newReviewTags);
		EditText desc = (EditText) findViewById(R.id.newReviewDescription);
		Spinner interests = (Spinner) findViewById(R.id.newReviewInterest);
		String tags = tag.getText().toString();
		String description = desc.getText().toString();
		String interest = interests.getSelectedItem().toString();

	/*	Log.i("Review", "Status: "+ NewReviewServiceClient.createNewReview("jyot", tags, description, interest, picturePath));*/
		NewReviewServiceClient.createNewReview(email, tags, description, interest, picturePath);
		alert.showAlertDialog(NewReviewActivity.this,
				"Success",
				"New Review Added", false);
	
	}

}
