package com.mobsquad.entity;

import java.io.InputStream;
import java.sql.Timestamp;


public class NewReview {
	private String email;
	private String tags;
	private String desciprtion;
	private String interest;
	private String imagePath;
	private InputStream inputStr;
	private Timestamp timestmp;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public String getDesciprtion() {
		return desciprtion;
	}
	public void setDesciprtion(String desciprtion) {
		this.desciprtion = desciprtion;
	}
	public String getInterest() {
		return interest;
	}
	public void setInterest(String interest) {
		this.interest = interest;
	}
	public Timestamp getTimestmp() {
		return timestmp;
	}
	public void setTimestmp(Timestamp timestmp) {
		this.timestmp = timestmp;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public InputStream getInputStr() {
		return inputStr;
	}
	public void setInputStr(InputStream inputStr) {
		this.inputStr = inputStr;
	}
	
}
