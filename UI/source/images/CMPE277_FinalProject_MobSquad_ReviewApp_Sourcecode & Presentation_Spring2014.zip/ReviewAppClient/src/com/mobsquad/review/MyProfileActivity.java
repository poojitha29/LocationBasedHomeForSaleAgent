package com.mobsquad.review;


import java.util.HashMap;
import java.util.ArrayList;


import com.mobsquad.client.NewReviewServiceClient;
import com.mobsquad.client.ProfileServiceClient;
import com.mobsquad.entity.Profile;
import android.app.Activity;
import android.app.ActionBar;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MyProfileActivity extends Activity {
	
	SessionManagement session;
	private static int RESULT_LOAD_IMAGE = 1;
	String picturePath = "";
	
	//private user myUser = new user();
	String email;
	String[] selIntArr;
	 String output;
	 
	 AlertDialogManager alert = new AlertDialogManager();
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		
		picturePath = "";
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_my_profile);
		ActionBar bar = getActionBar();
		bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00ccff")));
		session = new SessionManagement(getApplicationContext());
        
		HashMap<String, String> userEmail = session.getUserDetails();
		Log.i("session", "Email1");
		email = userEmail.get(SessionManagement.KEY_EMAIL);
		Log.i("session", "Email: " + email);
		
		 Bundle b = getIntent().getExtras();
         
		 if (b!=null){
			 selIntArr = b.getStringArray("setinterests");
			 output = arrayToString(selIntArr);
			 populatePostListwoInt(); 
		 } 
		 else
			 populatePostList();
       
	}

	
	 private void populatePostList() {
	    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
			.permitAll().build();
	    	StrictMode.setThreadPolicy(policy);
	    	
	    	ImageView imageView = (ImageView) findViewById(R.id.uImage);
            TextView userName = (TextView) findViewById(R.id.uName);
            TextView description = (TextView) findViewById(R.id.uDesp);
            TextView interest = (TextView) findViewById(R.id.myInterestEdit);
            TextView emailId = (TextView) findViewById(R.id.emailEditText);
            Bitmap image;
            Profile profiles = ProfileServiceClient.userProfile(email);
            int state = profiles.getFlag();
           
            if(state == 0){
            	
            image = BitmapFactory.decodeResource(getBaseContext().getResources(),R.drawable.user);
            imageView.setImageBitmap(image);
            userName.setText("Enter Your Name");
            description.setText("Enter description");
            interest.setText("Select Interest");
            emailId.setText(profiles.getEmail());
            }
            else if(state == 1){
            	String[] file = profiles.getU_image().split("/");
	    		String fileName = file[file.length-1];
	    		image = ProfileServiceClient.downloadProfileImage(profiles.getUserId(), fileName);
	    		
	    		imageView.setImageBitmap(image);
	            userName.setText(profiles.getU_name());
	            description.setText(profiles.getU_desp());
	            interest.setText(profiles.getU_interest());
	            emailId.setText(profiles.getEmail());
            }
	 }       
  
	 
	 private void populatePostListwoInt() {
	    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
			.permitAll().build();
	    	StrictMode.setThreadPolicy(policy);
	    	
	    	ImageView imageView = (ImageView) findViewById(R.id.uImage);
            TextView userName = (TextView) findViewById(R.id.uName);
            TextView description = (TextView) findViewById(R.id.uDesp);
            TextView interest = (TextView) findViewById(R.id.myInterestEdit);
            TextView emailId = (TextView) findViewById(R.id.emailEditText);
            Bitmap image;
	    	
	    	Profile proInt = ProfileServiceClient.userProfile(email);
	    	 int state = proInt.getFlag();
	    	
	    	 if(state == 0){
	            	
	             image = BitmapFactory.decodeResource(getBaseContext().getResources(),R.drawable.user);
	             imageView.setImageBitmap(image);
	             userName.setText("Enter Your Name");
	             description.setText("Enter description");
	             interest.setText(output);
	             emailId.setText(proInt.getEmail());
	             }
	             else if(state == 1){
	             	String[] file = proInt.getU_image().split("/");
	 	    		String fileName = file[file.length-1];
	 	    		image = ProfileServiceClient.downloadProfileImage(proInt.getUserId(), fileName);
	 	    		
	 	    		imageView.setImageBitmap(image);
	 	            userName.setText(proInt.getU_name());
	 	            description.setText(proInt.getU_desp());
	 	           interest.setText(output);
	 	            emailId.setText(proInt.getEmail());
	             }
	        }
    
	 
	 public void openMyPosts(View view){
    	
        Intent intent = new Intent(this, MyPostsActivity.class);
        startActivity(intent);
      
        }


    public void openMyInterests(View view){

        Intent intent = new Intent(this, InterestListActivity.class);
        startActivity(intent);
        finish();
    }
    
   public void uploadProPicClick(View v){
	   Intent i = new Intent(Intent.ACTION_PICK,
				android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
		startActivityForResult(i, RESULT_LOAD_IMAGE);
   	
   }
	
    public void UpdateProfile(View view){
    	
    	
	TextView userName1 = (TextView) findViewById(R.id.uName);
	TextView description1 = (TextView) findViewById(R.id.uDesp);
	TextView interest1 = (TextView) findViewById(R.id.myInterestEdit);
	TextView emailTxt1 = (TextView) findViewById(R.id.emailEditText);
	    
        String userName2 = userName1.getText().toString();
        String description2 =  description1.getText().toString();
        String interest2 = interest1.getText().toString();
        String emailTxt2 = emailTxt1.getText().toString();
        
    	//Log.i("Picture1", picturePath);
		//Log.i("ProfileUpdate", "Status: "+ ProfileServiceClient.update(emailTxt2, userName2, description2, interest2, picturePath));
		ProfileServiceClient.update(emailTxt2, userName2, description2, interest2, picturePath);
		alert.showAlertDialog(MyProfileActivity.this,
				"Success",
				"Profile updated.", false);
    }
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.my_profile, menu);
		return true;
	}

	 @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	    	
	    	switch(item.getItemId())
	        {
	    	case R.id.action_dashboard:
	    		Intent intentDB = new Intent(this, DashboardActivity.class);
	            startActivity(intentDB);
	            finish();
	            break;
	    	case R.id.action_logout:
	    		Intent intentlogout = new Intent(this, LoginActivity.class);
	            startActivity(intentlogout);
	            session.logoutUser();
	            finish();
	            break;
	        default:
	        	break;
	            
	        }
	    	return true;
	    	
	    }
	 


	private String arrayToString(String[] intarr) {
			
	 	     ArrayList list=new ArrayList();
	 	     for (int i=0; i<list.size(); i++)
	 	     {
	 	     list.add(intarr[i]);
	 	     }
	 	     String a=new String();

	 	     for(String p:intarr)
	 	     {
	 	    //  String x=new String(p);
	 	      a=a+new String(p)+",";
	 	     }
	 	    a = a.substring(0, a.length() - 1);
	 	    
	 	     return a;
	 	    }
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK
				&& null != data) {
			Uri selectedImage = data.getData();
			String[] filePathColumn = { MediaStore.Images.Media.DATA };

			Cursor cursor = getContentResolver().query(selectedImage,
					filePathColumn, null, null, null);
			cursor.moveToFirst();

			int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
			picturePath = cursor.getString(columnIndex);
			Log.i("Review", "path: " +picturePath );
			cursor.close();

			ImageView imageView = (ImageView) findViewById(R.id.uImage);
			imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
			Log.i("Picture", picturePath);

		}



}
}
