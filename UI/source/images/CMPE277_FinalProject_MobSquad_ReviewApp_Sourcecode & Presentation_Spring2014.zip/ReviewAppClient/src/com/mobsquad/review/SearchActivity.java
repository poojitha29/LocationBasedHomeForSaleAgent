package com.mobsquad.review;

import java.util.ArrayList;
import java.util.List;

import com.mobsquad.client.FeedServiceClient;
import com.mobsquad.constant.Constant;
import com.mobsquad.entity.Feed;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class SearchActivity extends Activity {
	
	
	private List<Post> myPosts = new ArrayList<Post>();
	String keyword;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search);

		ActionBar bar = getActionBar();
		bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00ccff")));
		
	
		  Bundle extras = getIntent().getExtras();
		  if (extras != null)
		  {
			  keyword = extras.getString("search");
			  Log.i("Query", keyword);
		  }
		  populatePostList();
		  populateListView();
		
			}

    private void populatePostList() {
    	
    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
		.permitAll().build();
    	StrictMode.setThreadPolicy(policy);
    	ArrayList<Feed> feeds = FeedServiceClient.searchKeyowrd(keyword);
    	
    	for(Feed feed: feeds)
    	{
    		String[] file = feed.getImagePath().split("/");
    		String fileName = file[file.length-1];
    		Bitmap image = FeedServiceClient.downloadReviewImage(feed.getReviewId(), fileName);
    		myPosts.add(new Post(feed.getEmail(), Constant.tags + feed.getTags(), Constant.description +feed.getDesp(), image));
    	}  

    }

    private void populateListView() {

        ArrayAdapter<Post> adapter1 = new MyListAdapter();
        ListView list = (ListView) findViewById(R.id.searchListView);
        list.setAdapter(adapter1);

    }
    
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.search, menu);
      
    	return super.onCreateOptionsMenu(menu);
    }
    
 
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return super.onPrepareOptionsMenu(menu);
    }
 
   
public boolean    onOptionsItemSelected  (MenuItem item) {
    	
    	switch(item.getItemId())
        {
    	
    	case R.id.action_refresh:
    		Intent intentrefresh = new Intent(this, DashboardActivity.class);
            startActivity(intentrefresh);
            finish();
            break;
    	default:
    		break;
    
        }
    	
    	return true;
    	
    }
	 
    private class MyListAdapter extends ArrayAdapter<Post>{

        public MyListAdapter(){
            super(SearchActivity.this,R.layout.search_listview,myPosts);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){
            
            View itemView = convertView;

            if(itemView == null){

                itemView = getLayoutInflater().inflate(R.layout.search_listview,parent,false);

            }

            Post currentPost = myPosts.get(position);

            ImageView imageView = (ImageView) itemView.findViewById(R.id.slistview_review_image);
            TextView username = (TextView) itemView.findViewById(R.id.slistview_username);
            TextView description = (TextView) itemView.findViewById(R.id.slistview_review_description);
            TextView tags = (TextView) itemView.findViewById(R.id.slistview_review_tags);
      
         
            imageView.setImageBitmap(currentPost.getImage());
            username.setText(currentPost.getEmail());
            description.setText(currentPost.getDescription());
            tags.setText(currentPost.getTag());
            
            return itemView;
        }

    }
}
