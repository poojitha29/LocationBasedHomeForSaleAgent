package com.mobsquad.entity;


import java.io.OutputStream;
import java.sql.Timestamp;

public class Feed {
	
	private int reviewId;
	private String email;
	private String imagePath;
	private OutputStream outputStr;
	private String keyword;
	private String tags;
	private String desp;
	private String status;
	private String interest;
	
	
	
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public OutputStream getOutputStr() {
		return outputStr;
	}
	public void setOutputStr(OutputStream outputStr) {
		this.outputStr = outputStr;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public String getDesp() {
		return desp;
	}
	public void setDesp(String desp) {
		this.desp = desp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInterest() {
		return interest;
	}
	public void setInterest(String interest) {
		this.interest = interest;
	}
	

}
