package com.mobsquad.review;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;

import java.util.Timer;
import java.util.TimerTask;

import com.mobsquad.entity.Session;

public class WelcomeScreenActivity extends Activity {

	private long ldelay = 3000;
	SessionManagement session;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_welcome_screen);
		session = new SessionManagement(getApplicationContext());
		
		session.checkLogin();
		
		TimerTask task = new TimerTask(){
			
			
			@Override
			public void run() {
				String status = SessionManagement.getSessionObj().getLoginStatus();	
				//Log.i("Status", status);	
			if(status == "true")
			{
				
				UserLoggedIn();
				finish();
			}
			else
				Login();
			}	
		};
		
		Timer timer = new Timer();
		timer.schedule(task, ldelay);
	}

	public void Login(){
		Intent loginIntent = new Intent(this, LoginActivity.class)	;
		startActivity(loginIntent);
		finish();
	}
	
	public void UserLoggedIn(){
		Intent loggedInIntent = new Intent(this, DashboardActivity.class)	;
		startActivity(loggedInIntent);
		finish();
	}
}
