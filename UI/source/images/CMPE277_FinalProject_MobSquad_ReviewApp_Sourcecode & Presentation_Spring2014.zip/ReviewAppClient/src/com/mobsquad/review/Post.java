package com.mobsquad.review;

import android.graphics.Bitmap;



public class Post {
	
	private String email;
	private String tag;
    private String description;
    private Bitmap image;

    Post(String email, String tag, String description, Bitmap image){

    	this.email = email;
    	this.tag = tag;
        this.description = description;
        this.image = image;
    }

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Bitmap getImage() {
		return image;
	}

	public void setImage(Bitmap image) {
		this.image = image;
	}

    
}
