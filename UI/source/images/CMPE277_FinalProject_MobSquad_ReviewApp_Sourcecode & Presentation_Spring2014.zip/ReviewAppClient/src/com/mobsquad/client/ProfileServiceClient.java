package com.mobsquad.client;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import com.mobsquad.constant.Constant;
import com.mobsquad.entity.Feed;
import com.mobsquad.entity.Profile;

public class ProfileServiceClient {
	
	public static boolean update(String email, String u_name, String u_desp,
			String u_interest, String fileName) {
		
		try{
		String url = Constant.url + "profile/update/" + email + "/" + u_name + "/" + u_desp + "/" + u_interest;

		HttpClient client = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(url);
		
		
		if (ProfileServiceClient.isExternalStorageReadable()) {
		FileBody fileContent = new FileBody(new File(fileName));
		MultipartEntity reqEntity = new MultipartEntity();
		reqEntity.addPart("file", fileContent);
		httppost.setEntity(reqEntity);
		}
		HttpResponse response = client.execute(httppost);

		if (response.getStatusLine().getStatusCode() == 200)
			return true;
	} catch (Exception e) {
		e.printStackTrace();
	}
	return false;

	}

/* Checks if external storage is available to at least read */
public static boolean isExternalStorageReadable() {
	String state = Environment.getExternalStorageState();
	Log.i("State", state);
	if (Environment.MEDIA_MOUNTED.equals(state)
			|| Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
		return true;
	}
	return false;
}

	public static Profile userProfile(String email) {
		Profile profiles = new Profile();

		try {
		String url = Constant.url+"profile/uprofile/"
				+ email;
		
		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);
		request.addHeader("accept", "application/json");
		
		HttpResponse response = client.execute(request);
		
		if (response.getStatusLine().getStatusCode() == 200) {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			
			
			JsonElement json = new JsonParser().parse(br);
			Gson gson = new Gson();
			profiles = gson.fromJson(json, Profile.class);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return profiles;
}
	
	public static Bitmap downloadProfileImage(int userId, String fileName) {
		try {
			Log.i("post", "userId: " + userId);
			String url = Constant.url + "profile/image/download/" + userId;
			HttpUriRequest request = new HttpGet(url);
			HttpClient httpClient = new DefaultHttpClient();
			HttpResponse response = httpClient.execute(request);
			StatusLine statusLine = response.getStatusLine();
			int statusCode = statusLine.getStatusCode();
			Bitmap bitmap = null;
			
			if (statusCode == 200) {
				HttpEntity entity = response.getEntity();
				byte[] bytes = EntityUtils.toByteArray(entity);
				System.out.println(bytes.length);
				
				bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
				return bitmap;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
