package com.mobsquad.constant;

public class Constant {

	public static String url = "http://54.187.184.164:8080/ReviewRestServer/";
	public static String description = "Description: ";
	public static String tags = "Tags: ";
}
