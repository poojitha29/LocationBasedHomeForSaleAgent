package com.mobsquad.review;


import com.mobsquad.client.SignupServiceClient;
import android.app.Activity;
import android.app.ActionBar;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class SignUpActivity extends Activity {
	
	static EditText sEmail,sPassword;
	Button signupbutton;
	AlertDialogManager alert = new AlertDialogManager();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sign_up);
		
		ActionBar bar = getActionBar();
		bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00ccff")));
		
		
		sEmail = (EditText) findViewById(R.id.email);
		sPassword = (EditText) findViewById(R.id.password);
		
		signupbutton = (Button) findViewById(R.id.sign_up_button);
	    signupbutton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			
				String email = sEmail.getText().toString();
				String password = sPassword.getText().toString();

				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
						.permitAll().build();
				StrictMode.setThreadPolicy(policy);
				
				if (email.trim().length() > 0 && password.trim().length() > 0) {

					if (SignupServiceClient.signupclient(email, password)) {
						
						Log.i("Signup", "done");
						
						Intent i = new Intent(getApplicationContext(),
								LoginActivity.class);
						startActivity(i);
						finish();
					} else {
						
						alert.showAlertDialog(SignUpActivity.this,
								"Signup Failed",
								"Please enter proper details", false);
					}
				} else {
					
							alert.showAlertDialog(SignUpActivity.this, "Signup Failed",
							"Please enter proper details", false);
				}
			}
		});
	}
}
