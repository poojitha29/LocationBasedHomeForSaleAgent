package com.mobsquad.client;

import java.io.File;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;

import android.os.Environment;

import com.mobsquad.constant.Constant;

public class NewReviewServiceClient {
	public static boolean createNewReview(String email, String tags,
			String desc, String interest, String filePath) {
		try {
			String url = Constant.url + "newpost/" + email + "/" + tags + "/"
					+ desc + "/" + interest;
			

			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(url);
			if (NewReviewServiceClient.isExternalStorageReadable()) {
				FileBody fileContent = new FileBody(new File(filePath));

				MultipartEntity reqEntity = new MultipartEntity();

				reqEntity.addPart("file", fileContent);

				httppost.setEntity(reqEntity);
			}
			HttpResponse response = httpclient.execute(httppost);

			if (response.getStatusLine().getStatusCode() == 200)
				return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/* Checks if external storage is available to at least read */
	public static boolean isExternalStorageReadable() {
		String state = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED.equals(state)
				|| Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
			return true;
		}
		return false;
	}
}
