package com.mobsquad.review;


import java.util.ArrayList;
import java.util.Currency;
import java.util.HashMap;

import java.util.List;



import com.mobsquad.client.FeedServiceClient;
import com.mobsquad.constant.Constant;
import com.mobsquad.entity.Feed;

import com.squareup.picasso.Picasso;



import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.SearchView.OnQueryTextListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class DashboardActivity extends Activity {
	
	SessionManagement session;
	TextView mSearchText;
	private List<Post> myPosts = new ArrayList<Post>();
	String email;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		ActionBar bar = getActionBar();
		bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00ccff")));
		mSearchText = new TextView(this);
		
		session = new SessionManagement(getApplicationContext());
		setContentView(R.layout.activity_dashboard);
		
		HashMap<String, String> userEmail = session.getUserDetails();
		Log.i("session", "Email1");
		email = userEmail.get(SessionManagement.KEY_EMAIL);
		Log.i("session", "Email: " + email);
        
		populatePostList();
        populateListView();
        

	}

    private void populatePostList() {
    	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
		.permitAll().build();
    	StrictMode.setThreadPolicy(policy);
    	ArrayList<Feed> feeds = FeedServiceClient.dashboardFeed(email);
    	
    	for(Feed feed: feeds)
    	{
    		String[] file = feed.getImagePath().split("/");
    		String fileName = file[file.length-1];
    		Bitmap image = FeedServiceClient.downloadReviewImage(feed.getReviewId(), fileName);
    		myPosts.add(new Post(feed.getEmail(), Constant.tags + feed.getTags(), Constant.description +feed.getDesp(), image));
    	}
   }

    private void populateListView() {
      
        ArrayAdapter<Post> adapter = new MyListAdapter();
        ListView list = (ListView) findViewById(R.id.postsListView);
        list.setAdapter(adapter);

    }
	 
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.actions, menu);
      
    	return super.onCreateOptionsMenu(menu);
    }
    
 
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return super.onPrepareOptionsMenu(menu);
    }
 
   
public boolean    onOptionsItemSelected  (MenuItem item) {
    	
    	switch(item.getItemId())
        {
    	case R.id.action_profile:
    		Intent intentprofile = new Intent(this, MyProfileActivity.class);
            startActivity(intentprofile);
            finish();
            break;
            
    	case R.id.action_search:
    		SearchDialog();
            break;
            
    	case R.id.action_refresh:
    		Intent intentrefresh = new Intent(this, DashboardActivity.class);
            startActivity(intentrefresh);
            finish();
            break;
    	case R.id.action_logout:
    		
    		Intent intentlogout = new Intent(this, LoginActivity.class);
            startActivity(intentlogout);
            session.logoutUser();
            finish();
            break;
    	default:
    		break;
    
        }
    	
    	return true;
    	
    }
   
    
    private class MyListAdapter extends ArrayAdapter<Post>{

        public MyListAdapter(){
            super(DashboardActivity.this,R.layout.dashboard_listview,myPosts);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){
            //Making sure we have a view to work with
            View itemView = convertView;

            if(itemView == null){

                itemView = getLayoutInflater().inflate(R.layout.dashboard_listview,parent,false);

            }

            Post currentPost = myPosts.get(position);

            ImageView imageView = (ImageView) itemView.findViewById(R.id.listview_review_image);
            
            TextView username = (TextView) itemView.findViewById(R.id.listview_username);
            TextView description = (TextView) itemView.findViewById(R.id.listview_review_description);
            TextView tags = (TextView) itemView.findViewById(R.id.listview_review_tags);
      
            imageView.setImageBitmap(currentPost.getImage());
            username.setText(currentPost.getEmail());
            description.setText(currentPost.getDescription());
            tags.setText(currentPost.getTag());
            
            return itemView;
        }

    }
    
    public void newReviewButtonClick(View v) {
    	
        Intent intent = new Intent(this, NewReviewActivity.class);
        startActivity(intent);
        finish();
    }

    public void SearchDialog(){
    		
    		LayoutInflater li = LayoutInflater.from(this);
    		View searchview = li.inflate(R.layout.searchquery, null);
    		
    		AlertDialog alertDialog = new AlertDialog.Builder(DashboardActivity.this).create();
    		alertDialog.setView(searchview);
    		
    		final EditText queryInput = (EditText) searchview.findViewById(R.id.searchinput);
    		
    		alertDialog.setCancelable(true);
    		
    		alertDialog.setButton(Dialog.BUTTON_POSITIVE, "Search", new DialogInterface.OnClickListener() {
    		public void onClick(DialogInterface dialog, int id) {
    			
    		String sea = queryInput.getText().toString();
    		Intent i1 = new Intent(getBaseContext(), SearchActivity.class);
    		i1.putExtra("search", sea);
            startActivity(i1);
            finish();
    	    }
    		});
    		
    		alertDialog.setButton(Dialog.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener()
    		{
    		    public void onClick(DialogInterface dialog,int id) {
    		    	dialog.cancel();
    		    }
    		  });
    		alertDialog.show();
			
    	}
    	
    
}
