package com.mobsquad.client;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mobsquad.constant.Constant;
import com.mobsquad.entity.Feed;

public class FeedServiceClient {

	public static ArrayList<Feed> dashboardFeed(String email) {
		ArrayList<Feed> feeds = new ArrayList<Feed>();

		try {
			
			String url = Constant.url + "feeds/dfeed/" + email;

			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);

			HttpResponse response = client.execute(request);

			if (response.getStatusLine().getStatusCode() == 200) {
				BufferedReader br = new BufferedReader(new InputStreamReader(
						response.getEntity().getContent()));

				JsonElement json = new JsonParser().parse(br);

				JsonArray array = json.getAsJsonArray();

				Iterator iterator = array.iterator();

				while (iterator.hasNext()) {
					JsonElement json2 = (JsonElement) iterator.next();
					Gson gson = new Gson();
					Feed feed = gson.fromJson(json2, Feed.class);
					feeds.add(feed);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return feeds;
	}

	public static ArrayList<Feed> userFeed(String email)
	{

		ArrayList<Feed> feeds = new ArrayList<Feed>();

		try {
		
			String url = Constant.url + "feeds/ufeed/" + email;
			
			HttpClient client = new DefaultHttpClient();
			HttpGet request = new HttpGet(url);
			
			HttpResponse response = client.execute(request);

			System.out.println("Response Code : "
					+ response.getStatusLine().getStatusCode());

			BufferedReader br = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));

			JsonElement json = new JsonParser().parse(br);

			JsonArray array = json.getAsJsonArray();

			Iterator iterator = array.iterator();

			while (iterator.hasNext()) {
				JsonElement json2 = (JsonElement) iterator.next();
				Gson gson = new Gson();
				Feed feed = gson.fromJson(json2, Feed.class);
				feeds.add(feed);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return feeds;
	}

	public static ArrayList<Feed> searchKeyowrd(String Keyword){
		
		ArrayList<Feed> feeds = new ArrayList<Feed>();

		try {
		String url = Constant.url + "feeds/search/" + Keyword;
		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);

		
		HttpResponse response = client.execute(request);

		System.out.println("Response Code : "
				+ response.getStatusLine().getStatusCode());

		BufferedReader br = new BufferedReader(new InputStreamReader(response
				.getEntity().getContent()));

		JsonElement json = new JsonParser().parse(br);

		JsonArray array = json.getAsJsonArray();

		Iterator iterator = array.iterator();

		while (iterator.hasNext()) {
			JsonElement json2 = (JsonElement) iterator.next();
			Gson gson = new Gson();
			Feed feed = gson.fromJson(json2, Feed.class);
			// can set some values in contact, if required
			feeds.add(feed);
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return feeds;
		
	}

	public static Bitmap downloadReviewImage(int reviewId, String fileName) {
		try {
			Log.i("post", "ReviewId: " + reviewId);
			String url = Constant.url + "feeds/reviews/download/" + reviewId;
			HttpUriRequest request = new HttpGet(url);
			HttpClient httpClient = new DefaultHttpClient();
			HttpResponse response = httpClient.execute(request);
			StatusLine statusLine = response.getStatusLine();
			int statusCode = statusLine.getStatusCode();
			Bitmap bitmap = null;
			
			if (statusCode == 200) {
				HttpEntity entity = response.getEntity();
				byte[] bytes = EntityUtils.toByteArray(entity);
				System.out.println(bytes.length);
				
				bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
				return bitmap;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
