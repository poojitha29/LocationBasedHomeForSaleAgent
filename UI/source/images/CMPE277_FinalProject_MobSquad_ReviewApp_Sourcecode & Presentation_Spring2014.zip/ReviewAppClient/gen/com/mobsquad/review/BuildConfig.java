/** Automatically generated file. DO NOT MODIFY */
package com.mobsquad.review;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}