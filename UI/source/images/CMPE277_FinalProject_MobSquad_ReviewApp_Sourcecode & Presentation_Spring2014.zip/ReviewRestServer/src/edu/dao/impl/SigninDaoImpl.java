package edu.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Timestamp;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

import edu.service.SignupService;
import edu.entity.Signin;




public class SigninDaoImpl {
	Connection conn = null;
	Statement stmt2 = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	
	
	public SigninDaoImpl(){
			getSingleConnection();
	}
	
	private void getSingleConnection()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/review", "root", "root");
			stmt2 = conn.createStatement();
			
			if (!conn.isClosed())
				System.out.println("Successfully connected");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	
	
	public String signin(Object object) {

		Signin si = (Signin) object ;
		
		String email = si.getEmail();
		String password = si.getPassword();
		
		
		String query = "";
		String result = "";
		
		try {
				query = "Select * from authentication where email='" + email + "'";
				rs =stmt2.executeQuery(query);
				
		
				if(!rs.first()){
					result = "{'status':'invalidemail'}";
				}
				else
				{
					String query1 = "Select password from authentication where email='" + email +"'";
					ResultSet rs1 = stmt2.executeQuery(query1);
					while(rs1.next()){
						if(password.equals(rs1.getString("password")))
						{
							result = "{'status':'successful'}";
						}
						
						else{
							result = "{'status':'failure'}";
					}
				}
			} 
		}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return result;
		

	}
}
						