package edu.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Timestamp;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

import edu.service.SignupService;
import edu.entity.Signup;




public class SignupDaoImpl {
	Connection conn = null;
	Statement stmt2 = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	
	
	public SignupDaoImpl(){
			getSingleConnection();
	}
	
	private void getSingleConnection()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/review", "root", "root");
			
			if (!conn.isClosed())
				System.out.println("Successfully connected");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public String signup(Object object) {

		Signup su = (Signup) object ;
		
		String email = su.getEmail();
		String password = su.getPassword();
		Timestamp timeStamp = su.getTimestamp();
 		
		String result = "";
		int rowcount;
		int rowcount1;

		try {
			
			String query = "Insert into authentication(email,password, timestamp) values (?, ?, ?)";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, email);
			stmt.setString(2, password);
			stmt.setTimestamp(3, timeStamp);
			rowcount = stmt.executeUpdate();
		
			if (rowcount > 0) {
				
				
				try{
					String query1 = "Insert into user_profile(email,flag) values (?,?)";
					stmt = conn.prepareStatement(query1);
					stmt.setString(1, email);
					stmt.setInt(2, 0);
					rowcount1 = stmt.executeUpdate();
					if (rowcount1 > 0) {
						result = "{'status':'successful'}";
				}else {
					result = "{'status':'failure'}";
					}
				}
					catch(MySQLIntegrityConstraintViolationException e)
					{
						result = "{'status':'duplicate'}";
					}
					catch (SQLException e) {
						e.printStackTrace();
						result = "{'status':'notinserted'}";
					}
			
				}else {
				result = "{'status':'failure'}";
			}
		}catch(MySQLIntegrityConstraintViolationException e)
		{
			result = "{'status':'duplicate'}";
		}
		catch (SQLException e) {
			e.printStackTrace();
			result = "{'status':'notinserted'}";
		}
		
		return result;
	}

}
