package edu.dao.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

import edu.entity.Feed;
import edu.entity.NewReview;
import edu.entity.Profile;
import edu.service.ProfileService;

public class ProfileDaoImpl {
	Connection conn = null;
	Statement stmt2 = null;
	PreparedStatement stmt = null;

	String query1 = "";
	String query2 = "";
	ResultSet rs1;
	ResultSet rs2;

	public ProfileDaoImpl() {
		getSingleConnection();
	}

	private void getSingleConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/review", "root", "root");
			stmt2 = conn.createStatement();

			if (!conn.isClosed())
				System.out.println("Successfully connected");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public String updateP(Object object) {

		Profile prf = (Profile) object;

		String email = prf.getEmail();
		String name = prf.getU_name();
		String description = prf.getU_desp();
		String interest = prf.getU_interest();
		InputStream inputStr = prf.getInputStr();
		String uImagePath = prf.getU_image();

		System.out.println("uImagePath Server : " + uImagePath);

		String result = "";

		int rowcount;

		try {
			
			String query = "UPDATE user_profile SET user_name = ?, user_desp = ?, user_interest = ?, user_image = ?, flag = ? WHERE email = ?";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, name);
			stmt.setString(2, description);
			stmt.setString(3, interest);
			stmt.setString(4, uImagePath);
			stmt.setInt(5, 1);
			stmt.setString(6, email);

			rowcount = stmt.executeUpdate();
			
			if (rowcount > 0) {
				result = "{'status':'successful'}";
				
				System.out.println("Profile Updated successfully!");
				if (uImagePath != "") {
					saveToFile(inputStr, uImagePath);
				}
			} 
			
			else {
				result = "{'status':'failure'}";
			}
		} catch (MySQLIntegrityConstraintViolationException e) {
			result = "{'status':'duplicate'}";
		} catch (SQLException e) {
			e.printStackTrace();
			result = "{'status':'notinserted'}";
		}
		
		return result;

	}

	public void saveToFile(InputStream uploadedInputStream,
			String uploadedFileLocation) {

		try {

			OutputStream out = null;
			int read = 0;
			byte[] bytes = new byte[1024];

			out = new FileOutputStream(new File(uploadedFileLocation));
			while ((read = uploadedInputStream.read(bytes)) != -1) {
				out.write(bytes, 0, read);
			}
			out.flush();
			out.close();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}


	public Profile uprofile(Object object) {

		Profile prfSet = null;
		Profile prf = (Profile) object;
		String email = prf.getEmail();
	
		try {
			query1 = "Select * from user_profile where email='" + email + "'";
			stmt = conn.prepareStatement(query1);
			rs1 = stmt.executeQuery();

			while (rs1.next()) {
				prfSet = new Profile();
				
				prfSet.setUserId(rs1.getInt("userId"));
				prfSet.setEmail(rs1.getString("email"));
				prfSet.setU_name(rs1.getString("user_name"));
				prfSet.setU_desp(rs1.getString("user_desp"));
				prfSet.setU_interest(rs1.getString("user_interest"));
				prfSet.setU_image(rs1.getString("user_image"));
				prfSet.setFlag(rs1.getInt("flag"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		return prfSet;

	}
	
	
	public String getPath(int userId) {

		try {
			String query = "Select * from user_profile where userId='" + userId
					+ "'";
			stmt = conn.prepareStatement(query);
			rs2 = stmt.executeQuery();

			while (rs2.next())
				return rs2.getString("user_image");

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}