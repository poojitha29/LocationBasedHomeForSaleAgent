package edu.dao.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

import edu.entity.NewReview;
import edu.entity.Signin;

public class NewReviewDaoImpl {
	Connection conn = null;
	Statement stmt2 = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	
	
	public NewReviewDaoImpl(){
			getSingleConnection();
	}
	
	private void getSingleConnection()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/review", "root", "root");
			
			if (!conn.isClosed())
				System.out.println("Successfully connected");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public String new_review(Object object) {

		NewReview rev = (NewReview) object ;

		String email = rev.getEmail();
		String tags = rev.getTags();
		String description = rev.getDesciprtion();
		String interest = rev.getInterest();
		InputStream inputStr = rev.getInputStr();
 		String imagePath = rev.getImagePath();
		
 		
 		long time = System.currentTimeMillis();
		Timestamp timeStamp = new Timestamp(time);
		
 		String result = "";
		int rowcount;
		
		try {
			
			String query = "Insert into reviews(email,tags,description,interest,imagePath,reviewTime) values (?,?,?,?,?,?)";
			stmt = conn.prepareStatement(query);
			stmt.setString(1, email);
			stmt.setString(2, tags);
			stmt.setString(3, description);
			stmt.setString(4, interest);
			stmt.setString(5, imagePath);
			stmt.setTimestamp(6, timeStamp);
			
			
		
			rowcount = stmt.executeUpdate();
			if (rowcount > 0) {
				result = "{'status':'successful'}";
				System.out.println("New Review Added successfully!");
				saveToFile(inputStr, imagePath);
				
				
			} else {
				result = "{'status':'failure'}";
			}
		}catch(MySQLIntegrityConstraintViolationException e)
		{
			result = "{'status':'duplicate'}";
		}
		catch (SQLException e) {
			e.printStackTrace();
			result = "{'status':'notinserted'}";
		}
		
		return result;
	}

	public void saveToFile(InputStream uploadedInputStream,
	        String uploadedFileLocation) {
	 
	        try {
	        	
	            OutputStream out = null;
	            int read = 0;
	            byte[] bytes = new byte[1024];
	 
	            out = new FileOutputStream(new File(uploadedFileLocation));
	            while ((read = uploadedInputStream.read(bytes)) != -1) {
	                out.write(bytes, 0, read);
	            }
	            out.flush();
	            out.close();
	        } catch (IOException e) {
	 
	            e.printStackTrace();
	        }
	 
	    }

}
