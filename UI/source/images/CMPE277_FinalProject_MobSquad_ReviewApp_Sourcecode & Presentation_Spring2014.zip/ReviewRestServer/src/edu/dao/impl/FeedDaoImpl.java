package edu.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;

import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;

import edu.entity.Feed;
import edu.entity.Profile;
import edu.entity.Signin;

public class FeedDaoImpl {

	Connection conn = null;
	Statement stmt2 = null;
	PreparedStatement stmt = null;
	String query2 = "";
	String query1 = "";
	String query3 = "";
	String query4 = "";
	ResultSet rs2;
	ResultSet rs1;
	ResultSet rs3;
	ResultSet rs4;
	ResultSet rs5;

	public FeedDaoImpl() {
		getSingleConnection();
	}

	private void getSingleConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/review", "root", "root");
			stmt2 = conn.createStatement();

			if (!conn.isClosed())
				System.out.println("Successfully connected");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Feed> dfeed(Object object) {

		ArrayList<Feed> feedData = new ArrayList<Feed>();
		Feed dFdSet = null;

		Feed dFd = (Feed) object;
		String email = dFd.getEmail();
		

		try {
			query1 = "Select user_interest from user_profile where email='"
					+ email + "'";
			stmt = conn.prepareStatement(query1);
			rs1 = stmt.executeQuery();

		
			while (rs1.next()) {
				System.out.println("RS1 : " + rs1.getString("user_interest"));
				String interest_string = rs1.getString("user_interest");

				String delims1 = "[,]";
				String[] interest_token = interest_string.split(delims1);

				ArrayList<String> querylist = new ArrayList<>();
				querylist.addAll(Arrays.asList(interest_token));

				System.out.println("User Interest Array"
						+ Arrays.toString(interest_token));
				System.out.println("User Interest List" + querylist);

				ListIterator<String> Litr = querylist.listIterator();

				while (Litr.hasNext()) {
					query2 = "Select * from reviews where interest='"
							+ Litr.next() + "'";
					stmt = conn.prepareStatement(query2);
					rs2 = stmt.executeQuery();

					while (rs2.next()) {
						dFdSet = new Feed();
						dFdSet.setReviewId(rs2.getInt("reviewId"));
						dFdSet.setEmail(rs2.getString("email"));
						dFdSet.setTags(rs2.getString("tags"));
						dFdSet.setDesp(rs2.getString("description"));
						dFdSet.setImagePath(rs2.getString("imagePath"));
						feedData.add(dFdSet);
					}

				}
			}
			// }
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return feedData;
	}

	
	public ArrayList<Feed> ufeed(Object object) {

		ArrayList<Feed> feedData1 = new ArrayList<Feed>();
		Feed uFdSet = null;

		Feed uFd = (Feed) object;
		String email = uFd.getEmail();
	
		try {
			query3 = "Select * from reviews where email='" + email + "'";
			stmt = conn.prepareStatement(query3);
			rs3 = stmt.executeQuery();

			
			while (rs3.next()) {
				uFdSet = new Feed();
				System.out.println(rs3.getInt("reviewId"));
				uFdSet.setReviewId(rs3.getInt("reviewId"));
				uFdSet.setEmail(rs3.getString("email"));
				uFdSet.setTags(rs3.getString("tags"));
				uFdSet.setDesp(rs3.getString("description"));
				uFdSet.setImagePath(rs3.getString("imagePath"));
				feedData1.add(uFdSet);
			}

			// }
		} catch (SQLException e) {
			e.printStackTrace();
			
		}

		return feedData1;

	}

	public ArrayList<Feed> search(Object object) {

		ArrayList<Feed> feedData2 = new ArrayList<Feed>();

		Feed sFdSet = null;

		Feed sFd = (Feed) object;
		String key = sFd.getKeyword();
		System.out.println(": " + key);
		

		try {

			query4 = "Select * from reviews where tags LIKE '%' ? '%'";
			stmt = conn.prepareStatement(query4);
			stmt.setString(1, key);
			rs4 = stmt.executeQuery();

			while (rs4.next()) {
				sFdSet = new Feed();
				sFdSet.setReviewId(rs4.getInt("reviewId"));
				sFdSet.setEmail(rs4.getString("email"));
				sFdSet.setTags(rs4.getString("tags"));
				sFdSet.setDesp(rs4.getString("description"));
				sFdSet.setInterest(rs4.getString("interest"));
				sFdSet.setImagePath(rs4.getString("imagePath"));

				feedData2.add(sFdSet);

			}
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		return feedData2;
	}

	public String getPath(int reviewId) {

		try {
			String query = "Select * from reviews where reviewId='" + reviewId
					+ "'";
			stmt = conn.prepareStatement(query);
			rs5 = stmt.executeQuery();

			while (rs5.next())
				return rs5.getString("imagePath");

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
