package edu.entity;

import java.io.InputStream;

public class Profile {
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	private int userId;
	private String email;
	private String u_name;
	private String u_desp;
	private String u_interest;
	private String u_image;
	private InputStream inputStr;
	private int flag;
	
	
	public int getFlag() {
		return flag;
	}
	public void setFlag(int flag) {
		this.flag = flag;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_desp() {
		return u_desp;
	}
	public void setU_desp(String u_desp) {
		this.u_desp = u_desp;
	}
	public String getU_interest() {
		return u_interest;
	}
	public void setU_interest(String u_interest) {
		this.u_interest = u_interest;
	}
	public String getU_image() {
		return u_image;
	}
	public void setU_image(String u_image) {
		this.u_image = u_image;
	}
	public InputStream getInputStr() {
		return inputStr;
	}
	public void setInputStr(InputStream inputStr) {
		this.inputStr = inputStr;
	}

}
