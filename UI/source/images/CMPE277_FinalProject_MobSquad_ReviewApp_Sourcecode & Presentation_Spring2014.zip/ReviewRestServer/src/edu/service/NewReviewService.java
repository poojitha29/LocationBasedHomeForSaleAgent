package edu.service;


import java.io.InputStream;




import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import edu.dao.impl.NewReviewDaoImpl;
import edu.entity.NewReview;


@Path("newpost")	
public class NewReviewService {
	
	
	@POST
    @Path("/{param}/{param1}/{param2}/{param3}")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces("application/json")
	public Response new_review(@PathParam("param") String email, @PathParam("param1") String tags, @PathParam("param2") String description,
			@PathParam("param3") String interest, @FormDataParam("file") InputStream uploadedInputStream,
	        @FormDataParam("file") FormDataContentDisposition fileDetail) 
	
	{
		System.out.println("new_review() function");
	 	String uploadedFileLocation = "C://imageData//" + fileDetail.getFileName();
		
	 	String output = null;
	 	
		NewReview rev = new NewReview();
		rev.setEmail(email);
		rev.setTags(tags);
		rev.setDesciprtion(description);
		rev.setInterest(interest);
		rev.setInputStr(uploadedInputStream);
	    rev.setImagePath(uploadedFileLocation);
	    NewReviewDaoImpl nrvdao = new NewReviewDaoImpl();
	    
	    Gson gson = new Gson();
		output = gson.toJson(nrvdao.new_review(rev));
	   
	    return Response.status(200).entity(output).build();
	    
	   
	}
	

}
