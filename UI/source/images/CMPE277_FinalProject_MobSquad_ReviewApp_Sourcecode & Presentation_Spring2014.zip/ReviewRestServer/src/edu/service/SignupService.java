package edu.service;


import edu.dao.impl.*;
import edu.entity.Signup;

import java.sql.Timestamp;





import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

@Path("signup")	
public class SignupService {
	
	@POST
    @Path("/{param}/{param1}")
	@Produces("application/json")
	public Response signup(@PathParam("param") String email, @PathParam("param1") String pass) {

		String output = "";
		
		long time = System.currentTimeMillis();
		Timestamp timestamp = new Timestamp(time);
		
		
	    	Signup su = new Signup();
	    	su.setEmail(email);
	    	su.setPassword(pass);
	    	su.setTimestamp(timestamp);
	    	
	    	SignupDaoImpl Sudao = new SignupDaoImpl();
	    	Gson gson = new Gson();
			output = gson.toJson(Sudao.signup(su));
		
	    	return Response.status(200).entity(output).build();
	    		
	}

}
