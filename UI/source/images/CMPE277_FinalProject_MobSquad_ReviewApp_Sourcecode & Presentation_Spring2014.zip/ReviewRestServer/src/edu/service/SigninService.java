package edu.service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import edu.dao.impl.SigninDaoImpl;
import edu.entity.Signin;

	@Path("signin")
	public class SigninService {
		@GET
		@Path("/{param}/{param1}")
		@Produces("application/json")
		public Response get_signin(@PathParam("param") String email, @PathParam("param1") String pass) {
		
		String output = "";
			
		Signin si = new Signin();
	    si.setEmail(email);
	    si.setPassword(pass);
		SigninDaoImpl Sidao = new SigninDaoImpl();
		
		Gson gson = new Gson();
		output = gson.toJson(Sidao.signin(si));
	   System.out.println(output);
	    	
	    return Response.status(200).entity(output).build();
			
		}
}
