package edu.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import com.google.gson.Gson;

import edu.dao.impl.FeedDaoImpl;
import edu.entity.Feed;

@Path("feeds")
public class FeedService {
		
		
		@GET
		@Path("/dfeed/{param}")
		@Produces("application/json")
		  public Response get_dfeeds(@PathParam("param") String email) {
			
			String output = null;
			
			Feed fd = new Feed();
			fd.setEmail(email);
			   
			FeedDaoImpl fdao = new FeedDaoImpl();
			ArrayList<Feed> feedData = fdao.dfeed(fd);
			
			if(feedData != null)
			{
			Gson gson = new Gson();
			System.out.println(gson.toJson(feedData));
			output = gson.toJson(feedData);
			return Response.status(200).entity(output).build();
			}
			return Response.status(600).entity("{'message': 'No Data Found'}").build();
		}
		
		@GET
		@Path("/ufeed/{param}")
		@Produces("application/json")
		public Response get_ufeeds(@PathParam("param") String email) {
			
			String output = null;
			
			Feed fd = new Feed();
			fd.setEmail(email);
			   
			FeedDaoImpl fdao = new FeedDaoImpl();
			ArrayList<Feed> feedData1 = fdao.ufeed(fd);
			
			if(feedData1 != null)
			{	
			Gson gson = new Gson();
			System.out.println(gson.toJson(feedData1));
			output = gson.toJson(feedData1);
			return Response.status(200).entity(output).build();
			}
			return Response.status(600).entity("{'message': 'No Data Found'}").build();
		}
		
		@GET
		@Path("/search/{param}")
		@Produces("application/json")
		public Response search_tags(@PathParam("param") String keyword) {
			

			String output = null;
			
			Feed fd = new Feed();
			fd.setKeyword(keyword);
			   
			FeedDaoImpl fdao = new FeedDaoImpl();
			ArrayList<Feed> feedData2 = fdao.search(fd);
			
			if(feedData2 != null)
			{	
			Gson gson = new Gson();
			System.out.println(gson.toJson(feedData2));
			output = gson.toJson(feedData2);
			return Response.status(200).entity(output).build();
		}
		return Response.status(600).entity("{'message': 'No Data Found'}").build();
		
		}
		
		@GET
		@Produces({ MediaType.APPLICATION_OCTET_STREAM })
		@Path("/reviews/download/{reviewId}")
		public Response getFile(@PathParam("reviewId") String reviewId){
			FeedDaoImpl dao = new FeedDaoImpl();
		   String filePath = dao.getPath(Integer.parseInt(reviewId));
		   if(filePath != null && !"".equals(filePath)){
		        File file = new File(filePath);
		        StreamingOutput stream = null;
		        try {
		        final InputStream in = new FileInputStream(file);
		        stream = new StreamingOutput() {
		            public void write(OutputStream out) throws IOException, WebApplicationException {
		                try {
		                    int read = 0;
		                        byte[] bytes = new byte[1024];

		                        while ((read = in.read(bytes)) != -1) {
		                            out.write(bytes, 0, read);
		                        }
		                } catch (Exception e) {
		                    throw new WebApplicationException(e);
		                }
		            }
		        };
		    } catch (FileNotFoundException e) {
		        e.printStackTrace();
		    }
		        return Response.ok(stream).header("content-disposition","attachment; filename = "+file.getName()).build();
		        }
		    return Response.ok("file path null").build();
		}
}

