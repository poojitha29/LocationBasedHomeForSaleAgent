package edu.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import com.google.gson.Gson;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;
import edu.dao.impl.ProfileDaoImpl;
import edu.entity.Profile;


@Path("profile")
public class ProfileService {
	
		@POST
	    @Path("/update/{param}/{param1}/{param2}/{param3}")
		@Consumes(MediaType.MULTIPART_FORM_DATA)
		@Produces("application/json")
		public Response update_profile (
				@PathParam("param") String email, 
				@PathParam("param1") String u_name, 
				@PathParam("param2") String u_desp, 
				@PathParam("param3") String u_interest,
				@FormDataParam("file") InputStream u_uploadedInputStream,
		        @FormDataParam("file") FormDataContentDisposition u_profilepic) 
		
		{
			
		 	String profilePicLocation = "C://imageUser//" + u_profilepic.getFileName();
			System.out.println("Location : " +profilePicLocation);
			String output = "";
			Profile prf = new Profile();
			prf.setEmail(email);
			prf.setU_name(u_name);
			prf.setU_desp(u_desp);
			prf.setU_interest(u_interest);
			
			
			if (u_profilepic.getFileName() != ""){
			prf.setInputStr(u_uploadedInputStream);
		    prf.setU_image(profilePicLocation);
			}
		   
			ProfileDaoImpl prfdao = new ProfileDaoImpl();
		    
		    Gson gson = new Gson();
		    output = gson.toJson(prfdao.updateP(prf));
		    return Response.status(200).entity(output).build();
		}
		
		
		@GET
		@Path("/uprofile/{param}")
		@Produces("application/json")
		  public Response get_uprofile(@PathParam("param") String email) {
			System.out.println("Inside get_uprofile() function");
			String output = null;
			
			Profile prf = new Profile();
			prf.setEmail(email);
			
			ProfileDaoImpl prfdao = new ProfileDaoImpl();
			Profile profileData = prfdao.uprofile(prf);
			if(profileData != null)
			{
				Gson gson = new Gson();
				System.out.println(gson.toJson(profileData));
				output = gson.toJson(profileData);
				return Response.status(200).entity(output).build();
			}
			return Response.status(600).entity("{'message': 'No Data Found'}").build();
		
		}
		
		@GET
		@Produces({ MediaType.APPLICATION_OCTET_STREAM })
		@Path("/image/download/{userId}")
		public Response getFile(@PathParam("userId") String userId){
		
			ProfileDaoImpl pdao = new ProfileDaoImpl();
		   String filePath = pdao.getPath(Integer.parseInt(userId));
		   if(filePath != null && !"".equals(filePath)){
		        File file = new File(filePath);
		        StreamingOutput stream = null;
		        try {
		        final InputStream in = new FileInputStream(file);
		        stream = new StreamingOutput() {
		            public void write(OutputStream out) throws IOException, WebApplicationException {
		                try {
		                    int read = 0;
		                        byte[] bytes = new byte[1024];

		                        while ((read = in.read(bytes)) != -1) {
		                            out.write(bytes, 0, read);
		                        }
		                } catch (Exception e) {
		                    throw new WebApplicationException(e);
		                }
		            }
		        };
		    } catch (FileNotFoundException e) {
		        e.printStackTrace();
		    }
		        return Response.ok(stream).header("content-disposition","attachment; filename = "+file.getName()).build();
		        }
		    return Response.ok("file path null").build();
		}
	}