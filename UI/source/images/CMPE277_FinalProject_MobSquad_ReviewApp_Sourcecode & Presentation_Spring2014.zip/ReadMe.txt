1)ReviewRestServer is the Jersey Rest Server where we have defined all the api's
2)ReviewRestClient is for HTTP Clients and Android Application acting as client to interact with the cloud deployed Restful server.


Team MobSSquad

Jyot Mankad
Namisha Goyal
Mohul Kaila
Harishwar Terupalli

Spring 2014 CMPE 277